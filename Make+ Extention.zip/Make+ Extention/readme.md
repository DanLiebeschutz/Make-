# Updates:
0.06 - icons + keyboard shortcut to initiate webhook
22/09/24 - submitted to chrome store review
0.05 - set the webhookUrl and the button title in the settings
0.04 - Red color if scenario is off
0.03 - stop errors for 30min button
0.02 - Date&time in DD/MM/YY HH:mm format
0.01 - notes name, date & time

# nextup:
github

# backlog:
performance
design
next feature

## done:
icons creation
chromestore
build + tests
create files

# Tools used:
vs code
openui.fly.dev
remove.bg
Canva
gsuit

# accounts:
gmail account - makeplusclub@gmail.com

# one time expenses:
$5 chrome developer registration fee

# recurring expenses:

